package com.example.gpaCal

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class Course (var name: String = "", var credit: Int = 0, var grade: String = "") : Parcelable {

    override fun toString() : String {
        return "Course(name=$name, credit=$credit, grade=$grade)"
    }
}

