package com.example.gpaCal

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.gpaCal.databinding.ActivityAddCourseBinding

import java.util.Collections

class AddCourseActivity : AppCompatActivity() {

    //Variables
    lateinit var binding : ActivityAddCourseBinding
    lateinit var Items: ArrayList<String>
    lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        //Binding
        binding = ActivityAddCourseBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Grade Spinner Data
        prepareData()
        adapter = ArrayAdapter<String>(this, android.R.layout.preference_category, Items)
        binding.gradeSpinner.setAdapter(adapter)

        //Listeners

        //Save Course Button
        binding.saveCourseButton.setOnClickListener {

            val courseName = binding.courseNametxt.text.toString()
            val credit = binding.creditSpinner.selectedItem.toString().toInt()
            val grade = binding.gradeSpinner.selectedItem.toString()

            //Validate
            if (courseName.isBlank() || credit == -1 || grade == "-1") {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else {
                // Create the course object
                val course = Course(name = courseName, credit = credit, grade = grade)

                // Send the object to main
                val resultIntent = Intent().apply {
                    putExtra("course", course)
                }
                setResult(RESULT_OK, resultIntent)
                finish()
            }
        }

        // Alter buttons
        binding.addbtn.setOnClickListener {
            adapter.add("A-")
            adapter.add("B+")
            adapter.add("B-")
            adapter.add("C+")
            adapter.add("C-")
            adapter.add("D+")
            adapter.add("D-")
            adapter.notifyDataSetChanged()//refresh
        }

        binding.subbtn.setOnClickListener {
            adapter.remove("A-")
            adapter.remove("B+")
            adapter.remove("B-")
            adapter.remove("C+")
            adapter.remove("C-")
            adapter.remove("D+")
            adapter.remove("D-")
            adapter.notifyDataSetChanged()//refresh
        }

        //Image view
        binding.gradeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedGrade = parent?.getItemAtPosition(position).toString()

                //Set image based on grade
                when (selectedGrade) {
                    "A" -> binding.img.setImageResource(R.drawable.a)
                    "A-" -> binding.img.setImageResource(R.drawable.a)
                    "B+" -> binding.img.setImageResource(R.drawable.b)
                    "B" -> binding.img.setImageResource(R.drawable.b)
                    "B-" -> binding.img.setImageResource(R.drawable.b)
                    "C+" -> binding.img.setImageResource(R.drawable.c)
                    "C" -> binding.img.setImageResource(R.drawable.c)
                    "C-" -> binding.img.setImageResource(R.drawable.c)
                    "D+" -> binding.img.setImageResource(R.drawable.d)
                    "D" -> binding.img.setImageResource(R.drawable.d)
                    "D-" -> binding.img.setImageResource(R.drawable.d)
                    "F" -> binding.img.setImageResource(R.drawable.f)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    //Functions
    fun prepareData() {
        Items = ArrayList()
        Collections.addAll(Items, "A", "B", "C", "D", "F")
    }
}