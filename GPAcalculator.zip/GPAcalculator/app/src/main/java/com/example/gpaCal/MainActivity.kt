package com.example.gpaCal

import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.animation.Animation
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.gpaCal.databinding.ActivityMainBinding
import com.example.gpaCal.databinding.DialogBinding
import com.google.android.material.snackbar.Snackbar


class MainActivity : AppCompatActivity() {

    //Variables
    lateinit var binding : ActivityMainBinding
    lateinit var bindingForDialog: DialogBinding
    private val courses = ArrayList<Course>()
    private val MAX_COURSES = 5
    lateinit var customDialog: Dialog
    var sem : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        //Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        bindingForDialog = DialogBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Launcher for add course
        val secondActivityResultLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            if (result.resultCode == RESULT_OK) {
                val course = result.data?.getParcelableExtra<Course>("course")
                if (course != null) {
                    courses.add(course)
                }
                updateCourseDisplay()

            } else {
                Toast.makeText(this, "Error Course Could Not Be Added", Toast.LENGTH_SHORT).show()
            }
        }

        //listeners

        //For Semester Custom Dialog
        binding.SemButton.setOnClickListener {
            customDialog.show()
        }
        createDailog()

        //For add course button
        binding.AddCourseButton.setOnClickListener {
            if (courses.size >= MAX_COURSES) {
                Toast.makeText(this, "Maximum 5 courses allowed!", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, AddCourseActivity::class.java)
                secondActivityResultLauncher.launch(intent)
            }
        }

        //For result
        binding.CalculateButton.setOnClickListener {
            if (courses.isEmpty()) {
                Toast.makeText(this, "Please add at least one course", Toast.LENGTH_SHORT).show()
            }
            else {
                val intent = Intent(this, ResultActivity::class.java).apply {
                    putExtra("sem", sem)
                    putParcelableArrayListExtra("courses", courses)
                }
                startActivity(intent)
            }
        }

        //For clear
        binding.clearBtn.setOnClickListener {
            val snackbar = Snackbar.make(
                binding.root,
                "Are you sure you want to clear all courses?",
                Snackbar.LENGTH_LONG
            ).setAction("YES") {
                courses.clear()
                sem = 0
                updateCourseDisplay()
                Snackbar.make(binding.root, "All courses cleared", Snackbar.LENGTH_SHORT).show()
            }
            snackbar.setActionTextColor(getColor(R.color.light_green)) //Custom color
            snackbar.setBackgroundTint(getColor(R.color.custom_blue)) //Custom Color
            snackbar.show()
        }

        //For delete buttons
        setupDeleteButtons()

        ////////// BLINK EFFECT
        // https://www.geeksforgeeks.org/how-to-create-blink-effect-on-textview-in-android/

        // adding the color to be shown
        val animator = ObjectAnimator.ofInt(binding.titletxt, "backgroundColor", Color.BLUE, Color.RED, Color.GREEN)

        // duration of one color
        animator.setDuration(500)
        animator.setEvaluator(ArgbEvaluator())

        // color will be show in reverse manner
        animator.setRepeatCount(Animation.REVERSE);

        // It will be repeated up to infinite time
        animator.setRepeatCount(Animation.INFINITE);
        animator.start();

    }

    //Functions
    fun createDailog() {
        customDialog = Dialog(this)
        customDialog.setContentView(bindingForDialog.root)

        bindingForDialog.dialogSaveButton.setOnClickListener(View.OnClickListener {
            val selectedId = bindingForDialog.semesterRadioGroup.checkedRadioButtonId
            if (selectedId != -1) {
                val radioButton = bindingForDialog.root.findViewById<RadioButton>(selectedId)
                sem = radioButton.text.toString().toInt()
                customDialog.dismiss()
            } else {
                Toast.makeText(this, "Please select a semester", Toast.LENGTH_SHORT).show()
            }
        })
        bindingForDialog.dialogCancelButton.setOnClickListener(View.OnClickListener { //customDialog.hide();
            customDialog.dismiss()
        })
    }

    private fun updateCourseDisplay() {
        // Hide all course items first
        for (i in 1..MAX_COURSES) {
            findViewById<LinearLayout>(resources.getIdentifier("courseItem$i", "id", packageName))
                ?.visibility = View.GONE
        }

        // Show and update course items based on current courses
        for (count in 1..courses.size) {
            //make the layout of each course visible
            val courseLayout = findViewById<LinearLayout>(resources.getIdentifier("courseItem$count", "id", packageName))

            // fill it up with data
            if (courseLayout != null) {
                courseLayout.visibility = View.VISIBLE

                val courseNameView = courseLayout.findViewById<TextView>(resources.getIdentifier("courseName$count", "id", packageName))
                courseNameView?.text = courses[count-1].name

                val creditTextView = courseLayout.findViewById<TextView>(resources.getIdentifier("creditText$count", "id", packageName))
                creditTextView?.text = "Credits: ${courses[count-1].credit}"

                val gradeTextView = courseLayout.findViewById<TextView>(resources.getIdentifier("gradeText$count", "id", packageName))
                gradeTextView?.text = "Grade: ${courses[count-1].grade}"

            }
        }
    }

    private fun setupDeleteButtons() {
        for (i in 1..MAX_COURSES) {

            //I couldn't find another way
            //Button is a view so we use ID tag
            val deleteButton = findViewById<ImageButton>(
                resources.getIdentifier("deleteButton$i", "id", packageName)
            )

            deleteButton?.setOnClickListener {
                // The index in the courses list is i-1
                // if this is button 1 then in the course array the course index is 0
                val courseIndex = i - 1
                showDeleteConfirmationDialog(courseIndex)
            }
        }
    }

    private fun showDeleteConfirmationDialog(courseIndex: Int) {
        AlertDialog.Builder(this)
            .setTitle("Delete Course")
            .setMessage("Are you sure you want to delete ${courses[courseIndex].name}?")
            .setPositiveButton("Delete") {dialog, which ->
                courses.removeAt(courseIndex)
                updateCourseDisplay()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}