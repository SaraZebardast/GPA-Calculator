package com.example.gpaCal

import android.os.Bundle
import android.widget.SeekBar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.gpaCal.databinding.ActivityResultBinding

class ResultActivity : AppCompatActivity() {

    //Variables
    lateinit var binding : ActivityResultBinding
    var cgpa : Double = 0.0
    var totalCredits : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        //Binding
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Get the semester and courses from intent
        val semester = intent.getIntExtra("sem", 0)
        val courses = intent.getParcelableArrayListExtra<Course>("courses") ?: ArrayList()
        var totalPoints = 0.0

        for (course in courses) {
            val gradePoints = when(course.grade) {
                "A" -> 4.0
                "A-" -> 3.7
                "B+" -> 3.3
                "B" -> 3.0
                "B-" -> 2.7
                "C+" -> 2.3
                "C" -> 2.0
                "C-" -> 1.7
                "D+" -> 1.3
                "D" -> 1.0
                "F" -> 0.0
                else -> 0.0
            }

            totalPoints += gradePoints * course.credit
            totalCredits += course.credit
        }

        cgpa = totalPoints / totalCredits

        //fix the seek bar proportions
        // seekbar only works with ints, so we multiply by 10 to get 4.0,3.5,etc
        binding.targetCgpaSeekBar.max = 40
        binding.targetCgpaSeekBar.progress = (cgpa * 10).toInt()


        //listeners

        // SeekBar listener
        binding.targetCgpaSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val targetCGPA = progress / 10.0
                binding.targetCGPAtext.text = "$targetCGPA"
                // Calculate required GPA
                calculateRequiredCGPA(targetCGPA)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        //Back to main button
        binding.backToMainButton.setOnClickListener {
            finish()
        }

        //Display
        binding.semesterDetailstxt.text = "Semester $semester"
        binding.resultCgpa.text = "%.2f".format(cgpa)
        binding.resultCredit.text = "$totalCredits"
    }

    //Functions
    private fun calculateRequiredCGPA(targetAGPA: Double) {
        // Calculate required GPA for next semester
        val requiredGpa = (targetAGPA * 2) - cgpa
        // Display result
        binding.requiredCgpaResult.text = when {
            requiredGpa > 4.0 -> "Not possible (> 4.0)"
            requiredGpa < 0.0 -> "Target already exceeded"
            else -> "%.2f".format(requiredGpa)
        }
    }
}